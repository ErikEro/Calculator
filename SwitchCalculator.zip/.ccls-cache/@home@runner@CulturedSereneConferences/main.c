#include <stdio.h>

int main(void) {

  float num1 , num2 ;
  char sym;
  
  printf("Input the function\n");
  
  scanf("%f %c %f", & num1, & sym, & num2);
  
  switch(sym){
    case '+':
      printf("Result is %.2f", num1+num2);
      break;
    
    case '-':
      printf("Result is %.2f", num1-num2);
      break;
    
    case '*':
      printf("Result is %.2f", num1*num2);
      break;
    
    case '/':
      if(num2==0){
        printf("Error\n");
      }
      else{
      printf("Result is %.2f", num1/num2);
      break;  
      }
    
      default:
      printf("I don't know what you are doing\n");
   
  }
    
  return 0;
}